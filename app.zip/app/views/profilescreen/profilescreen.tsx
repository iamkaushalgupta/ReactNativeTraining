import React from "react";
import {Text, View} from 'react-native';
import styles from "./style";


const ProfileScreen=()=>
{
    return(
        <View style={styles.container}>
            <Text>
                Profile Screen
            </Text>
        </View>
    );
}
export default ProfileScreen;   