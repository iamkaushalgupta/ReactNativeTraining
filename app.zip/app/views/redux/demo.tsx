import React from "react";
import {Text,View, Button, FlatList} from 'react-native';
import TestModel from '../../viewModels/testModel'


const Demo=()=>{
    const abc =[{1:"1",2:"2"}]
    return(
        <View>
            <TestModel/>
            </View>
    );
} 

export default Demo;