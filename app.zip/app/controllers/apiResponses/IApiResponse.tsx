export interface IApiResponse<T> {
    meta: any;
    data: T;
  }
  
