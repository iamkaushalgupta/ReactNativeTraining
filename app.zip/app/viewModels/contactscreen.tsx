import ContactScreen from "../views/contactscreen/contactscreen";
import React from "react";
const ContactModel=()=>
{
    return(<ContactScreen/>)
}

export default ContactModel;
