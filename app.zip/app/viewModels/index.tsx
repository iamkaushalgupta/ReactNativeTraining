import React from "react";
import HomeModel from "./homescreen";
import ContactModel from "./contactscreen";
import ProfileModel from "./profilescreen";

export {HomeModel,ContactModel, ProfileModel};