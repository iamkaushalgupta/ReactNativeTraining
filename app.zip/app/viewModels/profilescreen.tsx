import ProfileScreen from "../views/profilescreen/profilescreen";
import React from "react";

const ProfileModel=()=>
{
    return(<ProfileScreen/>)
}

export default ProfileModel;